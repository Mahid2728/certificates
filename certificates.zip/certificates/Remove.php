<?php
include 'connet.php';
$id=$_GET['id'];

            $sql = "DELETE FROM certificate WHERE id='$id' ";

				if (mysqli_query($conn, $sql)) {
					header('Location: list.php?log=1');
				} else {
				  echo "Error deleting record: " . mysqli_error($conn);
				}
        ?>