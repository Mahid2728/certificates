<?php
include 'connet.php';

if(isset($_POST['submit'])){
header('Content-Type: image/jpeg');
$font="ArianaVioleta.TTF";
$font2="Roboto-Bold.TTF";

$image=imagecreatefromjpeg("certificates.jpg");

$color=imagecolorallocate($image, 19, 21, 22);
$color2=imagecolorallocate($image, 126, 10, 133);

$name=$_POST['Name'];
$Roll=$_POST['Roll'];
$Registration=$_POST['Registration'];
$Subject=$_POST['Subject'];
$Father=$_POST['Father'];
$Mother=$_POST['Mother'];
$College=$_POST['College'];
$GPA=$_POST['GPA'];
$City=$_POST['City'];
$Serial=$_POST['Serial'];

imagettftext($image, 22, 0, 215, 190, $color, $font, $name);
imagettftext($image, 22, 0,380, 320, $color, $font, $Roll);
imagettftext($image, 20, 0,490, 100, $color, $font, $Registration);
imagettftext($image, 22, 0,370, 350, $color, $font, $Subject);
imagettftext($image, 22, 0,180, 220, $color, $font, $Father);
imagettftext($image, 22, 0,90, 253, $color, $font, $Mother);
imagettftext($image, 20, 0,85, 280, $color, $font, $College);
imagettftext($image, 21, 0,95, 372, $color, $font, $GPA);
imagettftext($image, 21, 0,140, 315, $color, $font, $City);
imagettftext($image, 12, 0,130, 103, $color2, $font2, $Serial);

$file=time();
$file_path=("img/".$file.".jpg");
$file_path_pdf=("pdf/".$file.".pdf");

imagejpeg($image,$file_path);
imagedestroy($image);

require('fpdf.php');
$pdf=new FPDF();
$pdf->AddPage();
$pdf->Image($file_path,0,0,210,150);
$pdf->Output($file_path_pdf,"F");
}
 header('Content-type:application.pdf');
 header('Content-Disposition: inline; filename"' . $file_path_pdf .'"');
 header('Content-Transfer-Encoding: binary');
 header('Accept-Ranges: bytes');
 @readfile($file_path_pdf);

 $q="INSERT INTO `certificate`(`Name`, `Roll`, `Registration`, `Subject`, `Father`, `Mother`, `College`, `GPA`, `City`, `Serial`, `img`, `pdf`) 
 VALUES ('$name', '$Roll','$Registration','$Subject','$Father','$Mother','$College','$GPA','$City','$Serial','$file_path','$file_path_pdf')";

$query = mysqli_query($conn, $q);

?>